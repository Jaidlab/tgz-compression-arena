class e{map
constructor(e={}){this.map=new Map(Object.entries(e))}get size(){return this.map.size}entries(){return this.map.entries()}forEach(e,t){for(let[r,s]of this.map.entries())e.call(t,s,r,this)}get(e){return this.map.get(e)}has(e){return this.map.has(e)}keys(){return this.map.keys()}[Symbol.iterator](){return this.entries()}values(){return this.map.values()}}var t=e
class r extends Error{static getMessage(e){return 1===e.length?`Missing required option: ${e[0]}`:`Missing required options: ${e.join(", ")}`}givenKeys
missingKeys
requiredKeys
constructor(e,t){let s=[...e],i=(e=>"string"==typeof e?[e]:[...e])(t),n=i.filter(e=>!s.includes(e))
super(r.getMessage(n)),this.name="RequiredOptionsError",this.givenKeys=s,this.requiredKeys=i,this.missingKeys=n}}var s=Symbol("optis.runtimeState"),i=new Set(["defaults","normalizations","optional","optionalKeys","required","requiredKeys"]),n=(e={})=>Object.freeze({defaults:Object.freeze({...e.defaults}),normalizations:Object.freeze({...e.normalizations}),requiredKeys:Object.freeze([...e.requiredKeys??[]])}),o=n(),a=["check","process","processMap","extend","extendTyped"]
function u(e,t){if(!e||"object"!=typeof e||Array.isArray(e))throw TypeError(`${t} must be an object.`)}function l(e,t){void 0!==e&&u(e,t)}var p=(e,t)=>{if(void 0===e)return[]
if("string"==typeof e)return[e]
if(Array.isArray(e)&&e.every(e=>"string"==typeof e))return[...e]
throw TypeError(`${t} must be a string or an array of strings.`)},f=(e,t)=>void 0===e?{}:(u(e,t),e),c=e=>{let t=new Set,r=[]
for(let s of e)t.has(s)||(t.add(s),r.push(s))
return r},d=e=>Object.hasOwn(e,s)?e[s]:o,y=(e,t)=>(Object.defineProperty(e,s,{configurable:!1,enumerable:!1,value:t,writable:!1}),e),h=(e,t)=>{let s=new Set(t)
for(let i of e)if(!s.has(i))throw new r(t,e)},O=e=>{if(void 0===e)return o
if(u(e,"Optis setup"),!(e=>Object.keys(e).some(e=>i.has(e)))(e))return n({defaults:e})
let t=f(e.defaults,"Optis setup.defaults"),r=((e,t)=>{let r=f(e,t),s=Object.entries(r)
for(let[e,r]of s)if("function"!=typeof r)throw TypeError(`${t}.${e} must be a function.`)
return Object.fromEntries(s)})(e.normalizations,"Optis setup.normalizations"),s=f(e.required,"Optis setup.required"),a=c([...Object.keys(s),...p(e.requiredKeys,"Optis setup.requiredKeys")])
return n({defaults:t,normalizations:r,requiredKeys:a})}
class b{constructor(e=o){y(this,e),Object.freeze(this)}check(e){l(e,"Optis options")
let t=d(this)
if(0===t.requiredKeys.length)return
let r=c([...Object.keys(t.defaults),...Object.keys(e??{})])
h(t.requiredKeys,r)}extend(e){return new b(((e,t)=>{let r=O(t)
return r===o?e:e===o?r:n({defaults:{...e.defaults,...r.defaults},normalizations:{...e.normalizations,...r.normalizations},requiredKeys:c([...e.requiredKeys,...r.requiredKeys])})})(d(this),e))}extendTyped(){return new b(d(this))}process(e){l(e,"Optis options")
let t,r=d(this),s=(e=>e??{})(e)
Object.keys(r.defaults).length>0&&(t={...r.defaults,...s})
let i=t??s
if(r.requiredKeys.length>0&&h(r.requiredKeys,Object.keys(i)),Object.keys(r.normalizations).length>0)for(let[e,n]of Object.entries(r.normalizations))Object.hasOwn(i,e)&&(t||(t={...s}),t[e]=n(t[e]))
return t??s}processMap(e){return new t(this.process(e))}}function m(e){return function(e=o){return new b(e)}(O(e))}var g,j=t,q=r;(g=m||={}).typed=m,g.ProcessedOptionsMap=j,g.RequiredOptionsError=q,((e,t=o)=>{y(e,t)
for(let t of a){let r=Object.getOwnPropertyDescriptor(b.prototype,t)
r&&Object.defineProperty(e,t,r)}})(m),Object.freeze(m)
var K=m
export{m as optis,K as default,r as RequiredOptionsError,t as ProcessedOptionsMap}
